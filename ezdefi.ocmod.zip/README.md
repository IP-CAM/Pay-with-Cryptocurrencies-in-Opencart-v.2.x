## How To Install
1) In your OpenCart admin panel go to Extensions > Installer
2) Upload the file ezdefi.ocmod.zip
3) Go to Extensions > Extensions, choose Payments from extension type
4) You will see ezDeFi module there, click the Install button
5) After installing finished, click on edit button to update ezDeFi settings.